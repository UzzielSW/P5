OVERVIEW

This program illustrates a simple concurrent program created by extending the Thread class.

TO COMPILE: javac ThreadExample.java

TO RUN: java ThreadExample
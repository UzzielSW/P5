OVERVIEW

This program illustrates a simple procedural program whose execution will be explained.

TO COMPILE: javac Procedural.java

TO RUN: java Procedural
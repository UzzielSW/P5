OVERVIEW

This program solves the Race Condition by implementing a BinarySemaphore.

TO COMPILE: javac SolveRaceCondition.java

TO RUN: java SolveRaceCondition
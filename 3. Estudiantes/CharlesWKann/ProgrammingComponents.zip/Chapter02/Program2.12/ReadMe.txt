OVERVIEW

This program shows a correct component to solve the problem in Program2.10.

TO COMPILE: javac SafeTurns_2.java

TO RUN: java SafeTurns
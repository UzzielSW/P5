OVERVIEW

This program shows how a component can coordinate two threads, but because
of the way it handles notify and wait calls, the program has dead lock 
condition.

TO COMPILE: javac SafeTurns.java

TO RUN: java SafeTurns
OVERVIEW

This program shows how a circular deadlock can occur in a program.

TO COMPILE: javac MakeDeadlock.java

TO RUN: java MakeDeadlock
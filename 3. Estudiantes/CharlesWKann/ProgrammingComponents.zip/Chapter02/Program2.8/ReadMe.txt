OVERVIEW

This program solves the Race Condition by using the Java synchronized statement.
The purpose is to show that the Java synchronized statement puts the equivalent of
a BinarySemaphore in the class automatically.

TO COMPILE: javac SolveRaceCondition_2.java

TO RUN: java SolveRaceCondition_2
OVERVIEW

This program illustrates a simple procedural program.

TO COMPILE: javac ProceduralExample.java

TO RUN: java ProceduralExample
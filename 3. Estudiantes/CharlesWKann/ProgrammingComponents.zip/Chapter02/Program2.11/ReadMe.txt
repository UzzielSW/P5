OVERVIEW

This program shows how a component can coordinate two threads, but it forces
the user's program to implement extra notify's to fix the problem in Program 2.10.
This is not a correct component.

TO COMPILE: javac SafeTurns_1.java

TO RUN: java SafeTurns
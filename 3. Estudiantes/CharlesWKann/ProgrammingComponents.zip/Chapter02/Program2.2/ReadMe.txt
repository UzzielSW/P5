OVERVIEW

This program illustrates a simple concurrent program created using a Runnable interface.

TO COMPILE: javac RunnableExample.java

TO RUN: java RunnableExample
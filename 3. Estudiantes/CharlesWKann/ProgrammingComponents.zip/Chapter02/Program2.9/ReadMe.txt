OVERVIEW

This program shows how a component can not coordinate two threads.

TO COMPILE: javac UnsafeTurns.java

TO RUN: java UnsafeTurns
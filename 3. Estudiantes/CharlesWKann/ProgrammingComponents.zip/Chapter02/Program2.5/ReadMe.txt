OVERVIEW

This program illustrates a simple concurrent program whose execution will be explained.

TO COMPILE: javac Concurrent.java

TO RUN: java Concurrent
OVERVIEW

This program shows an incorrect way to compare objects other than a Person
object in the Person's gt method.  It uses the SortedPrintTable from chapter
5, and modifies the Person.java file.  The other files are unchanged.

TO COMPILE: javac Person.java

TO RUN: java Person
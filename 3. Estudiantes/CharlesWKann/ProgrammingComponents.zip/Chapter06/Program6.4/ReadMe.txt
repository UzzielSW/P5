OVERVIEW

This directory shows 5 things that can be done with Exceptions.
Each ".java" file represents a separate Java program.

TO COMPILE: javac MultiCatch.java
            javac TryCatch_1.java
            javac TryCatch_2.java
            javac TryCatch_3.java
            javac ExceptionActions.java
   
       
TO RUN: java MultiCatch
        java TryCatch_1
        java TryCatch_2
        java TryCatch_3
        java ExceptionActions

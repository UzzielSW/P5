OVERVIEW

This program shows how to create an exception, including how to
include extra data in the exception to report additional information
to the try block

TO COMPILE: javac NumberTest.java

            Note that compiling NumberTest will also compile the 
            file for the NumberOutOfBoundsException.

TO RUN: java NumberTest

 
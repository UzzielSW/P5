OVERVIEW

This program shows shows how Java enforces a more correct error handling as
contrasted with C/C++.  In this program Program 6.3 is translated from C to
Java, and the proper Java error handling, as enforced by Java, is shown.

TO COMPILE: javac PrintFile.java

TO RUN: java PrintFile

        Note that the PrintFile program opens a file named tmp.dat.  Therefore
        a tmp.dat file is included in this directory.
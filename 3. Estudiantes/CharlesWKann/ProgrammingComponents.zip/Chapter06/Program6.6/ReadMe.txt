OVERVIEW

This program shows the use of a finally statement with a try block.

TO COMPILE: javac FinallyExample.java

TO RUN: java FinallyExample
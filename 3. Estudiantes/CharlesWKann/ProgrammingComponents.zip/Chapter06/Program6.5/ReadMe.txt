OVERVIEW

This program shows how exceptions are propogated in a Java program.

TO COMPILE: javac ExceptionPropogation.java

TO RUN: java ExceptionPropogation
OVERVIEW

This program shows that it is not the presence of a "throws" clause
that makes an exception checked, but rather what class it extends.

TO COMPILE: javac NotChecked.java

TO RUN: java NotChecked

 
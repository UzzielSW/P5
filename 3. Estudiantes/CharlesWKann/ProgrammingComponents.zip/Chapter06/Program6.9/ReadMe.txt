OVERVIEW

This program is to contrast how checked exceptions can be handled.  This
program shows that if the exception is not caught, it must be propogated.

TO COMPILE: javac Propogate.java

TO RUN: java Propogate

 
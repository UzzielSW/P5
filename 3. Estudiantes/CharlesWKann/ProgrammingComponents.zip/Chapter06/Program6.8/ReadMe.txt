OVERVIEW

This program is to contrast how checked exceptions can be handled.  The
first way is to catch them, which is illustrated in this program

TO COMPILE: javac CatchImmediate.java

TO RUN: java CatchImmediate

 
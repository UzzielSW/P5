OVERVIEW

This C files is used to show common, but invalid, error handling
in C/C++.  It does not handle all errors, and it incorrectly handles
the ones specified.


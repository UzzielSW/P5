OVERVIEW

Because of the incorrect attempt to fix the invalid object type bug in
Program 6.1, a knock on effect was created in inserting an invalid object
into the table.  A second incorrect fix is made here in an attempt to fix
the first problem, making things worse.  The SortedPrintTable's add method
was changed from Program 6.1, all other files are unchanged.

TO COMPILE: javac Person.java

TO RUN: java Person
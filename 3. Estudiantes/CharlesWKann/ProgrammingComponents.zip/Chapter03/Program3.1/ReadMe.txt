OVERVIEW

This program implements a simple Bounded Buffer problem with one Producer and one Consumer.

TO COMPILE: javac ProducerConsumer.java

TO RUN: java ProducerConsumer
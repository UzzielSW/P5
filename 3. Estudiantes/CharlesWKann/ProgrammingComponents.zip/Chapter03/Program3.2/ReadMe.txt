OVERVIEW

This program implements the Gas Station simulation

TO COMPILE: javac GasStation.java

TO RUN: java GasSTation
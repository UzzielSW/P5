OVERVIEW

This program extends the table from program 5.3 to sort the objects.  Only a
Person Table is shown.

TO COMPILE: javac Person.java
          
            Note: compiling Person will compile the PrintableSortable.java
            and SortedPrintTable.java files.

TO RUN: java Person
OVERVIEW

This program shows how polymorphism can be used to create algorithms that
operate on different types, in this case using an expression tree.

TO COMPILE: javac ExpressionTree.java
          
TO RUN: java ExpressionTree
OVERVIEW

These two C++ files show the use of templates in C++.  They cannot
be compiled in Java.


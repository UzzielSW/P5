public class Problem56 implements PrintableSortable {
    boolean eq(Sortable s) {
    }

    boolean gt(Sortable s) {
    }

    void print() {
    }
}

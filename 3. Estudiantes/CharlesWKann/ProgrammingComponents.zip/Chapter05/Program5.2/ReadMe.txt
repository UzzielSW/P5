OVERVIEW

This program shows how to implement a table that can store Person object.

TO COMPILE: javac PersonTable.java

TO RUN: java PersonTable
This document provides an overview of how to compile and run all the programs that
come with the text.  It tells you what you need to compile and run the programs,
any special commands or considerations needed to run the programs, and how the
directories are organized.

WHAT IS NEEDED TO RUN THE PROGRAMS

All the programs in this distribution were compiled with Java Developers Kit, JDK1.4.1.
The JDK is also called J2SE (Java 2 Standard Edition).  JDK1.4.1 can be found on Sun's
web site, java.sun.com, and can be downloaded for free.  You must install J2SE to run
the programs in this distribution.  Sun's web site also contains a tutorial for creating
a first program to insure that the J2SE is installed correctly at 
http://java.sun.com/docs/books/tutorial/getStarted/cupojava/index.html.

Note that the programs in this distribution do not work with JDK's before JDK1.4.  There
are several reasons for that.  The two most important are that JDK1.4 included some XML
classes which are used in some examples, and the java.awt.Color class was fixed to properly
name constants in all upper case letters, which is the standard way to name constants.
Readers using versions of the J2SE prior to JDK1.4 should either upgrade, or be prepared
for some programs that will not work, and others that need to be modified.

SPECIAL CONSIDERATIONS

Some of the programs in this book use a special package named "animator" to work correctly.
The readme in each subdirectory will explicitly state whether or not this package is needed
to make the programs work.  A script has been provided with this distribution, named 
"useAnimator.bat", that will correctly set up the CLASSPATH environment variable to use
the animator on Windows.  A similar script would have to be written for those using UNIX, 
but is not provided because it is dependent on the specific shell being used.

Documentation for the animator can be found by brining up the animatorDocs/index.html file.

HOW THE DIRECOTORIES ARE ORGANIZED

The source code in the directories is organized by Chapters.  All the source code for 
programs in Chapter 1 can be found in Chapter01, source code for Chapter 2 can be found 
in Chapter02, etc.  The sub directories in these chapters then matches the Programs as 
referenced in the text, so Program2.1 will be in directory Chapter02, subdirectory Program2.1.
The files are collected in sub directories so that all the files needed to build a complete
program are in a single directory.  So for example Program 7.1 required 3 ".java" files to compile,
and so there are 3 files in the directory "Chapter07/Program7.1".  By dividing the files up 
in this manner it is easier to build the programs, and keep track of the individual classes as 
there are cases where a class is rewritten and improved between programs.

Some files, such as Path.java, are first introduced in Program 7.1, and then used in other 
programs throughout the text.  In cases such as this, the program will be presented and commented 
on in the text in Program 7.1 only.  When it is used in subsequent programs, it is copied to the
correct directory to make it easier to compile.

Each sub directory will have a ReadMe.txt file much like this one.  It will tell what the program
is suppose to do, and will tell how to compile and run the program.  Any special instructions
needed to make the program work will also be covered in the ReadMe.txt.
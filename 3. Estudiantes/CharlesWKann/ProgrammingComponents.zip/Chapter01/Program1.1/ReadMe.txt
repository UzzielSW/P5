OVERVIEW

This program illustrates that a program that uses a GUI interface is concurrent.

TO COMPILE: javac Fibbonacci.java

TO RUN: java Fibbonacci
OVERVIEW

NOTE:  This program uses the animator created in Program 7.5  You must
make sure that this animator is in your CLASSPATH.  If you are on windows, 
and have not already done so, run the UseAnimator.bat script found in the
base directory for this distribution once each time you start a DOS shell.

This program shows what happens when the animator is used with threads.  
Because the threads being animated are not coordinated with the animator,
if the animator is slowed down, the balls in the animation appear to jump.

TO COMPILE: javac ConcurrentBall.java


To RUN: java ConcurrentBall

 
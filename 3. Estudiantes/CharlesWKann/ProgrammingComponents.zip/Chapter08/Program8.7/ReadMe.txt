OVERVIEW

NOTE:  This program uses the animator created in Program 7.5  You must
make sure that this animator is in your CLASSPATH.  If you are on windows, 
and have not already done so, run the UseAnimator.bat script found in the
base directory for this distribution once each time you start a DOS shell.

This program implements the animator with the Gas Station Simulation presented
in Chapter 3. 

TO COMPILE: javac GasStation.java

To RUN: java GasStation
 
/**
 * TITLE: Program 13.4d
 *
 * @(#)ChatClient.java 2002/07/21
 * @author Charles W. Kann III
 *
 * Copyright (c) 2002 CRC Press
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this
 * copyright notice appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
import java.io.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

/**
 *   Purpose: This program sets up the GUI to be used by
 *   the Chat program, and registers with the server.
 */

public class ChatClient extends UnicastRemoteObject
                    implements ChatListener, Serializable {
    

    private ChatServer chatServer;
    private TextArea messageBox;


    public ChatClient() throws java.rmi.RemoteException {
        createFrame();
        try {
            chatServer =(ChatServer)Naming.lookup(
                "//localhost/ChatServer");
            chatServer.addChatListener(this);
        } catch(Exception e) {
            e.printStackTrace();
        }

    }

    public void createFrame() {
        
        JFrame chatFrame = new JFrame("Chat Program");
        Container chatContainer = chatFrame.getContentPane();

        JScrollPane sp = new JScrollPane(messageBox = new TextArea(40, 10));
        messageBox.setEditable(false);
        chatContainer.add(messageBox, BorderLayout.CENTER);

        JPanel controlPanel = new JPanel();
        final TextField inputText = new TextField(40);
        controlPanel.add(inputText);

        JButton sendButton = new JButton("Send");
        sendButton.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    chatServer.sendChatMessage(inputText.getText() + "\n");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                inputText.setText("");
            }
        });
        controlPanel.add(sendButton);

        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    chatServer.removeChatListener(ChatClient.this);
                    System.exit(0);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        controlPanel.add(exitButton);

        chatContainer.add(controlPanel, BorderLayout.SOUTH);

        chatFrame.setSize(500,400);
        chatFrame.setVisible(true);
    }

    public void chatEventSent(ChatEvent ce) 
            throws java.rmi.RemoteException {
        messageBox.append(ce.getMessage());
    }

    public static void main(String argv[]) {
        try {
            ChatClient chatClient = new ChatClient();
        } catch (Exception e ) {
            e.printStackTrace();
        }
    }
}

/**
 * TITLE: Program 13.4b
 *
 * @(#)ChatEvent.java 2002/07/21
 * @author Charles W. Kann III
 *
 * Copyright (c) 2002 CRC Press
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this
 * copyright notice appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

/**
 *   Purpose: This is an Event interface for a Event State object
 *   that will be passed as part of the Java Event Model for the
 *   Chat program.  Note that the event travels between the Event Source
 *   the the Event Listener, and since they are in separate processes, 
 *   the Event object must be a migrating object.
 *
 *   Note that this file is kept with the server to keep all the Java Event
 *   Model files together in this application.
 */

public class ChatEvent extends java.util.EventObject {
    String message;
    public ChatEvent(Object source, String message) {
        super(source);
        this.message = new String(message);
    }

    public String getMessage() {
        return message;
    }
}

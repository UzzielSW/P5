/*
 * TITLE: Program 13.4a
 *
 * @(#)ChatListener.java 2002/07/21
 * @author Charles W. Kann III
 *
 * Copyright (c) 2002 CRC Press
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this
 * copyright notice appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

/**
 *   Purpose: This is an Event Listener that allows remote processes to
 *   register themselves with a remote event source (in this case, a 
 *   ChatServer).  Because the listener extends remote, the object that
 *   implements it will be non-migrating (it will stay on the computer
 *   where it was created).  This is important because the ChatClient is
 *   the GUI interface for the client, and as such should remain on the
 *   computer where it was created.
 *
 *   Note that this file is kept with the server to keep all the Java Event
 *   Model files together in this application.
 */

interface ChatListener extends java.rmi.Remote, java.util.EventListener {
    public void chatEventSent(ChatEvent cme)
        throws java.rmi.RemoteException;
}


/**
 * TITLE: Program 13.4d
 *
 * @(#)ChatServerImp.java 2002/07/21
 * @author Charles W. Kann III
 *
 * Copyright (c) 2002 CRC Press
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this
 * copyright notice appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

/**
 *   Purpose: This is the event server.  Note that listeners 
 *   register with this server, and when one wants to send a 
 *   message, the sendChatMessage method is called.  This is 
 *   the "processEvent" type call in this Event Source, and
 *   it causes an Event State object to be created and sent
 *   to all of the Listeners on this Event Source.
 */

public class ChatServerImp extends UnicastRemoteObject
        implements ChatServer {

    Vector chatListeners = new Vector();

    public ChatServerImp() throws RemoteException {
    }

    public void addChatListener(ChatListener cl)
                throws java.rmi.RemoteException {
        System.out.println("Adding Listener");
        chatListeners.add(cl);
    }

    public void removeChatListener(ChatListener cl)
                throws java.rmi.RemoteException {
        System.out.println("Removing Listener");
        chatListeners.remove(cl);
    }

    public void sendChatMessage(String message)
            throws java.rmi.RemoteException {
        Vector v;
        synchronized(this) {v = (Vector)chatListeners.clone();}

        try {
            for (Enumeration e = v.elements(); e.hasMoreElements();) {
                ChatListener cl = (ChatListener)e.nextElement();
                cl.chatEventSent(new ChatEvent(this, message));
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String argv[]) {
        try {
            ChatServerImp thisExample = new ChatServerImp();

            Naming.rebind("//localhost/ChatServer", thisExample);
        } catch (Exception e) {
                System.out.println("ChatServer err: " + e.getMessage());
                e.printStackTrace();
        }
    }
}

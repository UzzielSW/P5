Program 13.4 implements a simple chat program.  User's type in one chat
window, and the message shows up in all the associated chat windows.

This document explains how to run program 13.4.  All programs in this
directory have been compiled and the class files properly distributed to
make it easier to make this run the first time.  Instructions on how to
rebuild the files are given in Chapter 13 of the textbok.

To run program 13.4, first open 3 command prompts (in MS Windows) or 3
shell prompts (Unix).  Change directory to the server directory in the first
two windows, and to the client directory in the third window.

In the first window type "rmiregistry".  This will start rmiregistry
using the default port.  Make sure you are in the server directory when doing
this.  rmiregistry will start correctly if you do not, but the client
and server will not run properly.

In the second window type "java ChatServerImp".  This will start the server
program.  

In the third window (the only one in the client directory) type
"java ChatClient".  A GUI window will open up which will allow entry of
text at the bottom of the window.  When the send button is pressed, this text
will be sent to every listener registered with the server.

When you have completed running the program, go to all the windows
and type "Ctrl-C" (the Ctrl key and C key together) to stop the programs.

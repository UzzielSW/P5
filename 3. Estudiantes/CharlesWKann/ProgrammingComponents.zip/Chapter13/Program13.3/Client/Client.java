/*
 * TITLE: Program 13.2c
 *
 * @(#)Client.java 2002/07/21
 * @author Charles W. Kann III
 *
 * Copyright (c) 2002 CRC Press
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this
 * copyright notice appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

import java.rmi.*;

/**
 *   Purpose: This implements the client for both the migrating
 *   and the non-migrating objects example.  It is a very 
 *   standard RMI client except for the fact the the call to
 *   "server.sendMessage()" will either call a local or remote
 *   object depending on how the PrintMessage class is implemented.
 */

class Client {
    public static void main(String argv[]) {
        try {
            Server server = (Server)Naming.lookup(
                "//localhost/Server");
            server.sendMessage(
                new PrintMessageImp("Created on Client"));
        } catch(Exception e) {
            e.printStackTrace();
        }
    }


}

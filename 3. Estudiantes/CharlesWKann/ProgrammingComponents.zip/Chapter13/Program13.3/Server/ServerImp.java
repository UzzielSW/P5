/*
 * TITLE: Program 13.2b
 *
 * @(#)ServerImp.java 2002/07/21
 * @author Charles W. Kann III
 *
 * Copyright (c) 2002 CRC Press
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this
 * copyright notice appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.io.*;

/**
 *   Purpose: This implements the server for both the migrating
 *   and the non-migrating objects example.  It is a very 
 *   standard RMI server, except for the fact the the call to
 *   "pm.print()" in the sendMessage() method will be either
 *   local or remote depending on how the PrintMessage object
 *   is implement in the client.
 */

class ServerImp extends UnicastRemoteObject
                implements Server, Serializable {
    
    public ServerImp() throws java.rmi.RemoteException {
        super();
    }

    public void sendMessage(PrintMessage pm) {
        try {
            pm.print();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String argv[]) {
        try {
            ServerImp thisExample = new ServerImp();
            Naming.rebind("/Server", thisExample);
            System.out.println("bound in registry");
        } catch (Exception e) {
            System.out.println("HelloGuy err: " + e.getMessage());
            e.printStackTrace();
        }
    }


}

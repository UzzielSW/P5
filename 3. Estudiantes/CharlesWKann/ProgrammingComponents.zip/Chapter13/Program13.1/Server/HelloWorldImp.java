/*
 * TITLE: Program 13.1b
 *
 * @(#)HelloWorldImp.java 2002/07/21
 * @author Charles W. Kann III
 *
 * Copyright (c) 2002 CRC Press
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this
 * copyright notice appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.io.*;

/**
 *   Purpose: This implements the server for the HelloWorld program.
 */


/**
 *  This class is a simple RMI server.  To be a server using RMI, this
 *  class implements the following:
 *
 *    1 - It extends the remote interface, in this case interface HelloWorld.
 *    2 - It extends UnicastRemoteObject.
 *    3 - The constructor must throw java.rmi.RemoteException, as the 
 *        parent constructor for UnicastRemoteObject throws this exception.
 *    4 - It sets up the security manager (if needed).  It is not used here,
 *        so it is commented out.  To use it the policytool program needs to
 *        be run to set the policy before running this application.
 *    5 - The object is created, and registered with rmiregistry using the
 *        Naming.rebind() call.  Note that in this example, to show that the
 *        default RMI port does not have to be used, port 5012 is used.  Be
 *        careful when starting this program to use the correct port.
 */

class HelloWorldImp extends UnicastRemoteObject
                implements HelloWorld {
    
    /**
     *  public constructor.  This simply runs the parent constructor.
     */
    public HelloWorldImp() throws java.rmi.RemoteException {
        super();
    }

    /**
     *  Method from the remote interface.  Note that this method
     *  is called remotely from the client.  Also note that this
     *  method does not throw java.rmi.RemoteException, even though
     *  the interface defines it for this method.  The exception will
     *  be added when rmic is run.
     */
    public void PrintHello() {
        System.out.println("Hello from Local");
    }

    /**
     *  The main method, which creates the object and registers it with
     *  rmiregistry.
     */
    public static void main(String argv[]) {
        try {

            // The security manager is only needed if the class is to
            // be loaded across the network.  This code is commented 
            // out because we will distribute the classes before starting 
            // the client and the server
            /******
            if (System.getSecurityManager() == null) {
                System.setSecurityManager(new RMISecurityManager());
            }
            */

            HelloWorldImp thisExample = new HelloWorldImp();
            Naming.rebind("//localhost:5012/HelloGuy", thisExample);

            // This is not needed, but it tells us the rebind worked.
            System.out.println("HelloGuy bound in registry");

        } catch (Exception e) {
            System.out.println("HelloGuy err: " + e.getMessage());
            e.printStackTrace();
        }
    }


}

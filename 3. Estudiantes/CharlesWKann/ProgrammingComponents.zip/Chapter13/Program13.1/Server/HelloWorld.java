/*
 * TITLE: Program 13.1a
 *
 * @(#)HelloWorld.java 2002/07/21
 * @author Charles W. Kann III
 *
 * Copyright (c) 2002 CRC Press
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this
 * copyright notice appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

import java.rmi.Remote;
import java.rmi.server.UnicastRemoteObject;

/**
 *   Purpose: This implements the interface for the HelloWorld program.
 */

/**
 *  This is an RMI interface.  To work with RMI this interface must do
 *  the following:
 *    1 - The interface must extend java.rmi.Remote.
 *    2 - All remote methods must be declared to throw java.rmi.RemoteException.
 *        Note that the exception does not have to be thrown when the Server
 *        implements the method, as rmic adds the exception to the method in
 *        the stub class.
 *
 *  This interface is needed by both the client and the server, and defines how
 *  they communicate with each other.  However the client only needs the class
 *  file to compile, so only the ".class" file should be put with the client code.
 */

public interface HelloWorld extends java.rmi.Remote {
    public void PrintHello()
        throws java.rmi.RemoteException;
}


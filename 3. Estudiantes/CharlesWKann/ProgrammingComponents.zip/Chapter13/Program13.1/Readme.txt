This document explains how to run program 13.1.  All programs in this
directory have been compiled and the class files properly distributed to
make it easier to make this run the first time.  Instructions on how to
rebuild the files are given in Chapter 13 of the textbok.

To run program 13.1, first open 3 command prompts (in MS Windows) or 3
shell prompts (Unix).  Change directory to the server directory in the first
two windows, and to the client directory in the third window.

In the first window type "rmiregistry 5012".  This will start rmiregistry
using the port 5012.  Make sure you are in the server directory when doing
this, and that you start rmiregistry with port 5012.  rmiregistry will start
correctly if you do not, but the client and server will not run properly.

In the second window type "java HelloWorldImp".  This will start the server
program.  The server program will print out a message when it is registered
with rmiregistry.

In the third window (the only one in the client directory) type
"java HelloWorldClient".  This will start the client program.  The client
program will complete with no output, but a message should print in the
second window running the server, showing that the client program connected
to the server.  If this happens, you have gotten this example program to
run.  Note that you can run the client many times, and it will continue to
produce output in the server window.

When you have completed running the program, go to the windows running
the server and rmiregistry and type "Ctrl-C" (the Ctrl key and C key
together) to stop the programs.

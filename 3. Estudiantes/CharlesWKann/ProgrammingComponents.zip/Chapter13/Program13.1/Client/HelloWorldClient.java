/*
 * TITLE: Program 13.1c
 *
 * @(#)HelloWorldClient.java 2002/07/21
 * @author Charles W. Kann III
 *
 * Copyright (c) 2002 CRC Press
 * All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for NON-COMMERCIAL purposes
 * and without fee is hereby granted provided that this
 * copyright notice appears in all copies.
 *
 * THE AUTHOR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE
 * SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT. THE AUTHOR SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

import java.rmi.*;

/**
 *   Purpose: This implements the client for the HelloWorld program.
 */


/**
 *  Client program for an RMI program.  To be a server, the program
 *  must do the following: 
 *    1 - set the security manager to allow the stub class to be
 *        loaded from the server (if needed.  It is not used here,
 *        and so is commented out).
 *    2 - Retrieve the remote object from the rmiregistry programming
 *        running on the server computer.  Note that in this example, 
 *        to show that the default RMI port does not have to be used, 
 *        port 5012 is used.  Be careful when starting this program to 
 *        use the correct port.
 *    3 - Call the object using the interface as if it were local.
 */
class HelloWorldClient {
    public static void main(String argv[]) {
        try {

            // If the stub class was loaded across the network, this
            // would have to be set.  But we are distributing all the
            // class files to the right directories, so this is not
            // needed here.  See the Server code for more details.
            /***********
            if (System.getSecurityManager() == null) {
                System.setSecurityManager(new RMISecurityManager());
            }
            */

            HelloWorld H =(HelloWorld)Naming.lookup(
                "//localhost:5012/HelloGuy");
            H.PrintHello();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }


}

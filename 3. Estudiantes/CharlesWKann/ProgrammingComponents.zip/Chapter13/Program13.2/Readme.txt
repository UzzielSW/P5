Program 13.2 shows how an object can move (migrate) to another process
and run in the other process.  When the output from this program comes
out, it will be in the window for the server process.

This document explains how to run program 13.2.  All programs in this
directory have been compiled and the class files properly distributed to
make it easier to make this run the first time.  Instructions on how to
rebuild the files are given in Chapter 13 of the textbok.

To run program 13.2, first open 3 command prompts (in MS Windows) or 3
shell prompts (Unix).  Change directory to the server directory in the first
two windows, and to the client directory in the third window.

In the first window type "rmiregistry".  This will start rmiregistry
using the default port.  Make sure you are in the server directory when doing
this.  rmiregistry will start correctly if you do not, but the client
and server will not run properly.

In the second window type "java ServerImp".  This will start the server
program.  The server program will print out a message when it is registered
with rmiregistry.

In the third window (the only one in the client directory) type
"java Client".  This will start the client program.  The client
program will complete with no output, but a message should print in the
second window running the server, showing that the PrintMessage object
was transferred to the server and is running on the server.

When you have completed running the program, go to the windows running
the server and rmiregistry and type "Ctrl-C" (the Ctrl key and C key
together) to stop the programs.

OVERVIEW

This program is used to show how a memory is allocated for a vector, and how it is serialized.

TO COMPILE: javac VectorMemory.java

TO RUN: java VectorMemory
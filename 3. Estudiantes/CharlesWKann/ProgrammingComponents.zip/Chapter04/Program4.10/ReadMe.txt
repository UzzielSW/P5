OVERVIEW

This program is uses XML to show what Java must do when serializing memory.

TO COMPILE: javac Person.java

TO RUN: java Person
OVERVIEW

This program an invalid cast that is caught at run time.

TO COMPILE: javac CastError1.java

TO RUN: java CastError1
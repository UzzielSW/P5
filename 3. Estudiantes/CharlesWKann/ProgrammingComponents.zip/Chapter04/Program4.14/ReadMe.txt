OVERVIEW

This program shows some simple vector operations.

TO COMPILE: javac ShowVector.java

TO RUN: java ShowVector
OVERVIEW

This program allocates an array of objects.  Note that allocating an array of
objects is fundementally different than allocating an array of primitives.

TO COMPILE: javac ArrayOfObjects.java

TO RUN: java ArrayOfObjects
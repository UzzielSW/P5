OVERVIEW

This program what happens in Java if a reference is made
to a object where the compile time type does not have the
necessary functions defined, even though the object that 
would exist at run time would have those the correct definition.

TO COMPILE: javac ReferenceError.java

TO RUN: java ReferenceError
OVERVIEW

This program shows allocating an array of primitives.

TO COMPILE: javac ArrayOfPrimitives.java

TO RUN: java ArrayOfPRimitives
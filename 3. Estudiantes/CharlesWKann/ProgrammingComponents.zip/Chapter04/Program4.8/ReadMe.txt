OVERVIEW

This program an invalid cast that is caught at compile time.

TO COMPILE: javac CastError2.java

TO RUN: java CastError2
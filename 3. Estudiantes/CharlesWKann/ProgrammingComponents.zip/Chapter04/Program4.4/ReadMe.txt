OVERVIEW

This program shows that the Java run time keeps track of the type
at run time, and can give correct error messages if a program tries
to set a variable to the wrong runtime type.

TO COMPILE: javac RuntimeError.java

TO RUN: java RuntimeError
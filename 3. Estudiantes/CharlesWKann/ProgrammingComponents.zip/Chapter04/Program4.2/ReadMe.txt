OVERVIEW

This program using a Simple C variable.  It is a C program and cannot be run
with Java.  The purpose is to show that variables in C can have a runtime and
a compile time type.
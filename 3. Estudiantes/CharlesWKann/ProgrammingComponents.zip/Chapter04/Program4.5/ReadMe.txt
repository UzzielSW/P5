OVERVIEW

This program shows that java can handle invalid casting errors.

TO COMPILE: javac CatchCast.java

TO RUN: java CatchCast
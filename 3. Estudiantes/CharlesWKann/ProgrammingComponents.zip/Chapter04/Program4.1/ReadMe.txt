OVERVIEW

This program using a Simple C variable.  It is a C program and cannot be run
with Java.

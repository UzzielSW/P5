OVERVIEW

This program shows we can query the Java run time type, so casts are always correct.

TO COMPILE: javac CorrectCast.java

TO RUN: java CorrectCast
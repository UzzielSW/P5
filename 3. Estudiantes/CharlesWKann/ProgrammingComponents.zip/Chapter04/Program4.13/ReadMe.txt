OVERVIEW

This program randomly creates objects to show that polymorphism must resolve
methods at run time since there is no way that the compiler can know for sure 
the type of object.

TO COMPILE: javac RandomCreate.java

TO RUN: java RandomCreate
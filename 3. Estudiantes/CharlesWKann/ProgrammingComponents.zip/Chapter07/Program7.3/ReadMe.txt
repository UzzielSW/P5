OVERVIEW

This program is a first step towards creating a generic animator,
one that can be used with many different objects, and one that can
be used in many different programs.

TO COMPILE: javac MoveObject.java

            Note that MoveObject is a main program that uses the
            animator.  It is not part of the animator.  All other
            files in this directory represent part of the animator.
            When the using program is compiled, all the other parts
            of the animator are compiled, so compiling the MoveObject.java
            files will compile all the other files in this directory.

TO RUN: java MoveObject

 
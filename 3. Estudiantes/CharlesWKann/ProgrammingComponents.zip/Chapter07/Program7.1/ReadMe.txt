OVERVIEW

This program introduces a simple animator.  The purpose is to show how
animation can be accomplished, and to introduce the concept of a Path
that an animated object will travel.  Note that this animator is not
general enough to be useful, and it is flawed in that it calls sleep
in the paint method.

TO COMPILE: javac SimpleAnimator.java

            Note that compiling NumberTest will also compile the 
            files for the Path.java and StraightLinePath.java files.

TO RUN: java SimpleAnimator

 
OVERVIEW

This program shows the a second implemenation of a FIFOBS.  This
implementation attempts to use a Notification Object in a way that
is more consistant with the spirit of the monitors from Chapter 3.

TO COMPILE: javac FIFOBS.java

To RUN: java FIFOBS

 
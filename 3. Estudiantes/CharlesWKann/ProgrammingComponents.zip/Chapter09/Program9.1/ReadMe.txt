OVERVIEW

This program shows the implementation of a First-In-First-Out-Binary-Semaphore.
This is a fair semaphore.  It shows how a Notification Object can be used
with the monitor from Chapter 3.

TO COMPILE: javac FIFOBS.java

To RUN: java FIFOBS

 
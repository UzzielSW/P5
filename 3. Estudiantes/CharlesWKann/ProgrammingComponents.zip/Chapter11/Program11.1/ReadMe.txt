OVERVIEW

The programs in this directory can be compiled, but are really meant to be
illustrative of composition and classification to build objects. The programs
will not run even if compiled.
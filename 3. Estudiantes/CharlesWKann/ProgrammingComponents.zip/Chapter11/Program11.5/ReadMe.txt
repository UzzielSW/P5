OVERVIEW

This program shows how the java composition can be used to implement
polymorphism, and that polymorphism is not dependant on inheritence.
It is the compositional equivalent of program 11.2

TO COMPILE: javac Employee.java

To RUN: java Employee
 
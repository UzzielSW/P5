OVERVIEW

This program shows how the java extends clause can be used to create 
subclasses that implement polymorphism, much like an interface.  However
unlike interfaces, the base classes (in this case an abstract class) can
define data and some methods.

TO COMPILE: javac Employee.java

To RUN: java Employee
 
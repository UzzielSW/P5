OVERVIEW

The program in this directory can be compiled, but is really meant to
illustrate a how Java can implement the equivalent of multiple inheritence
of Program 11.6 using composition.  The program will not run if compiled.
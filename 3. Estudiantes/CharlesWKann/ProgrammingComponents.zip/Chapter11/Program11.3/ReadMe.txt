OVERVIEW

The program in this directory can be compiled, but is really meant to
illustrate the improper use of classification to organize an object.
The program will not run even if compiled.
OVERVIEW

The program in this directory can be compiled, but is really meant to
illustrate a more proper organization of an object using composition.
The program will not run even if compiled.
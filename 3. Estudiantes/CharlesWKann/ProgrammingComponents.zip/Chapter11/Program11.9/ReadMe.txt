OVERVIEW

This program shows the compositional equivalent to classification structure
used to define operators in Prgram 11.8.

TO COMPILE: javac Operator.java

To RUN: java Operator
 
OVERVIEW

This program shows how the java extends clause can be used to create 
subclasses of an operator to implement add and subtract operations.

TO COMPILE: javac Operator.java

To RUN: java Operator
 
OVERVIEW

The program in this directory cannot be compiled. It is meant to
illustrate multiple inheritence, which is not available in Java.
OVERVIEW

This program shows the use of the java.util.Stack class, and why classification
was probably not the best design decision that could be made in creating it.

TO COMPILE: javac UseStack.java

To RUN: java UseStack
 
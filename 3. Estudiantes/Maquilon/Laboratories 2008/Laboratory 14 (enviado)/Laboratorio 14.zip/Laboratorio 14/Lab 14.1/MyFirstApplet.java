
import java.applet.*;

import java.awt.*;

public class MyFirstApplet extends Applet
{
	public void paint(Graphics g)
	{
		g.drawString("Bienvenido Ing. Maquilon", 30, 30);
	}
}
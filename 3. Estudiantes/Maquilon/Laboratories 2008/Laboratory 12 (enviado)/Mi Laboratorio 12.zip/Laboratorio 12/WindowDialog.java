
	import java.awt.*;

	import javax.swing.*;
	

public class WindowDialog extends JDialog
{
	private JButton send, cancel;
	
	private JTextArea message_area;
	
	private static final Font system = new Font("Bookman Old Style", Font.BOLD,13);
	

	public WindowDialog(Frame window, String person)
	{		
		super(window, "SendMessage Dialog", true);

		Container contentPane = this.getContentPane();
		
	
	
		//  Boton send
		
		send = new JButton("Send");
		
		send.setFont(system);
		
		
		
		//  Boton cancel
		
		cancel = new JButton("Cancel");
		
		cancel.setFont(system);
		
		
		
		message_area = new JTextArea();
		
		message_area.setBorder(BorderFactory.createLineBorder(Color.black));
		
		message_area.setBackground(Color.white);

		JPanel south = new JPanel();
		
		south.add(send);
		
		south.add(cancel);
		
		contentPane.add(south, BorderLayout.SOUTH);
		

		JScrollPane center = new JScrollPane(message_area);
		
		contentPane.add(center, BorderLayout.CENTER);

		JLabel north = new JLabel("Sending message to " + person);
		
		north.setFont(system);
		
		contentPane.add(north, BorderLayout.NORTH);
	
		this.setSize(400,200);
	}


	public static void main(String [] args)
	{
		WindowDialog d = new WindowDialog(null, "simon");
		
		d.setLocationRelativeTo(null);
		
		d.show();
	}
}

import java.awt.*;

import javax.swing.*;

public class WindowFrame extends JFrame
{
	public WindowFrame(String title)
	{
		super(title);
		
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

	public static void main(String [] args)
	{
		JFrame f = new WindowFrame("  My WindowFrame");
		
		f.setSize(235,450);
		
		f.setLocationRelativeTo(null);
		
		f.setVisible(true);
	}
}


	import java.awt.*;
	
	import javax.swing.*;


public class FrameMessage extends JFrame
{
	private JList friends;
	private JTextField message;
	private JButton send;

	public FrameMessage(String title)
	{
		super(title);
		
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		JPanel south = getMessagePanel();
		
		JScrollPane center = getFriendsPane();

		Container contentPane = this.getContentPane();
		
		contentPane.add(south, BorderLayout.SOUTH);
		
		contentPane.add(center, BorderLayout.CENTER);
	}

	private JPanel getMessagePanel()
	{
		JPanel panel = new JPanel(new BorderLayout());
		
		message = new JTextField();
		
		message.setBorder(BorderFactory.createLineBorder(Color.black));
		
		send = new JButton("Send");
		
		send.setBackground(new Color(0,0,128));
		
		send.setForeground(Color.WHITE);

		panel.add(message, BorderLayout.CENTER);
		
		panel.add(send, BorderLayout.EAST);

		return panel;
	}

	private JScrollPane getFriendsPane()
	{
		friends = new JList();
		
		JScrollPane pane = new JScrollPane(friends);
		
		pane.setBackground(new Color(202,225,255));
		
		return pane;
	}
	


	public static void main(String [] args)
	{
		JFrame f = new FrameMessage("My IM Program");
		
		f.setSize(220,450);
		
		f.setLocationRelativeTo(null);
		
		f.setVisible(true);
	}
}


import java.util.*;

public class TestReminder
{
	public static void main(String [] args)
	{
		Timer tiempo = new Timer();
		
		Reminder welcome = new Reminder("Hola Sr. Maquilon !\n");
		
		Reminder answer = new Reminder("Que desea en este dia ?\n");
		
		Reminder farewell = new Reminder("Fue es un placer servirle, vuelva pronto !\n");

		tiempo.schedule(welcome, 0);
		
		tiempo.schedule(answer, 30000);
		
		tiempo.schedule(farewell, 200000);
	}
}
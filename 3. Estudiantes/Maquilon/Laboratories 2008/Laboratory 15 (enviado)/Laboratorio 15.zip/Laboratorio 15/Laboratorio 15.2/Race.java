

import java.io.*;

public class Race
{
	// Esta sentencia es para leer datos de entrada, mediante el teclado.
	
	private static final BufferedReader leer = new BufferedReader(new InputStreamReader(System.in)); 
	
	public static void main(String [] argumentos) throws IOException
	{
		Thread [] carros = new Thread[2];
		
		
		
		// aqui se ingresa el nombre de dos(2) competidores
		
		String [] competidores = new String[5];
		
		for(int i = 0; i < carros.length; i++)
		{
			System.out.println("Ingrese el nombre de los competidores");
			
			competidores[i] = leer.readLine();
		}
		
		
		
		
		// define el # de vueltas antes de comenzar la carrera
		
		String vueltas;		

		System.out.println("Ingrese el # de vueltas");
		
		vueltas = leer.readLine();
		
		int V = Integer.parseInt(vueltas);
		
		
		
		
		// crea dos(2) hilos ya que son dos(2) competidores

		for(int i = 0; i < carros.length; i++)
		{
			carros[i] = new RaceCar(competidores[i], V);
		}

		for(int i = 0; i < carros.length; i++)
		{
			carros[i].start();
		}
	}
}
public class RaceCar extends Thread
{
	private String nombre;
	
	private int la_meta;

	public RaceCar(String conductor, int Final)
	{
		this.la_meta = Final;
		
		this.nombre = conductor;
	}

	public void run()
	{
		
	for(int i = 1; i <= la_meta; i++)
	{
			
	int tiempo = (int) (Math.random() * 6000);
			
	
	// Aqui se define el tiempo que dormira cada hilo, segun sea su turno.
	
	try
	{
		Thread.sleep(tiempo);
	}
			
	catch(InterruptedException m){  }
	
	
	// Aqui se imprimira el nombre de cada hilo, dependiendo tambien de su turno.
			
	System.out.println(nombre + " " + i);
	
	}
		
		System.out.println(nombre + " Llego a la Final!");
	}
}

import java.io.*;

public class Print
{
	private static final BufferedReader leer = new BufferedReader(new InputStreamReader(System.in)); 
	
	public static void main(String [] main) throws IOException
	{
		PrintNumbers PN = new PrintNumbers();
		
		Thread thread_1 = new Thread(PN);
		
		String tiempo;		

		System.out.println("Ingrese el tiempo en segundos, en que el main dormira");
		
		tiempo = leer.readLine();
		
		tiempo = tiempo+"000";
		
		int T = Integer.parseInt(tiempo);
		
		thread_1.start();

		try
		{
			Thread.sleep(T);
		}
		
		catch(InterruptedException e){ }
		
		PN.stopPrinting();
		
		System.out.println("main() is ending");
	}
}